echo "Enter the Limit: " 
read number

if ! [[ "$number" =~ ^[1-9][0-9]*$ ]]; then
    echo "Error: Please enter a positive integer."
    exit 1
fi
count=0
num=2
while [ $count -lt $number ]; do
    is_prime=true
    for ((i = 2; i * i <= num; i++)); do
        if [ $((num % i)) -eq 0 ]; then
            is_prime=false
            break
        fi
    done
    if $is_prime; then
        echo -n "$num "
        count=$((count + 1))
    fi
    num=$((num + 1))
done
echo
