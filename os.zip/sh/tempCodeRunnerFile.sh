echo "Enter the first number: "
read num
if [$num -gt 2] then
i=2
limit=`expr $num/2`
do 
if[`expr $num % $i` - eq 0]
then
echo "num not prime"
f=1
exit
fi
done
if [$f -eq 0]
then
echo "Num is prime"
fi