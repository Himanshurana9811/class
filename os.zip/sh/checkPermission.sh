# Find out whether-Given file exits, File has read, write and execute
# permissions?
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <filename>"
    exit 1
fi
filename=$1
# Check if the file exists
if [ ! -e "$filename" ]; then
    echo "File $filename does not exist."
    exit 1
fi
# Check read permission
if [ -r "$filename" ]; then
    echo "File $filename has read permission."
else
    echo "File $filename does not have read permission."
fi
# Check write permission
if [ -w "$filename" ]; then
    echo "File $filename has write permission."
else
    echo "File $filename does not have write permission."
fi
# Check execute permission
if [ -x "$filename" ]; then
    echo "File $filename has execute permission."
else
    echo "File $filename does not have execute permission."
fi