# To generate mark sheet of a student. Take 3 subjects, calculate and display total marks, percentage and Class obtained by the student
echo "Enter marks for Subject 1: " 
read subject1
echo "Enter marks for Subject 2: " 
read subject2
echo "Enter marks for Subject 3: " 
read subject3
if ! [[ "$subject1" =~ ^[0-9]+$ && "$subject2" =~ ^[0-9]+$ && "$subject3" =~ ^[0-9]+$ ]]; then
    echo "Error: Please enter valid numeric marks."
    exit 1
fi
total_marks=$((subject1 + subject2 + subject3))
percentage=$(powershell.exe -command "[math]::Round($total_marks / 3, 2)")
echo "Total Marks: $total_marks"
echo "Percentage: $percentage%"A
if (( $(echo "$percentage >= 75") )); then
    echo "Class: Distinction"
elif (( $(echo "$percentage >= 60") )); then
    echo "Class: First Class"
elif (( $(echo "$percentage >= 45") )); then
    echo "Class: Second Class"
else
    echo "Class: Fail"
fi