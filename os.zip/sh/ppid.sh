#  Created n child processes using for loop and print the PID and PPID of each child processes
n=5
parent_pid=$$
echo "Parent Process PID: $parent_pid"
for ((i=1; i<=n; i++)); do
    # Fork a new child process
    child_pid=$(($$ + i))
    echo "Child Process $i - PID: $child_pid, PPID: $parent_pid"
done
