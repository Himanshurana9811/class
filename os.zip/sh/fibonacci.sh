read -p "Enter the value of n: " n
if ! [[ "$n" =~ ^[1-9][0-9]*$ ]]; then
    echo "Error: Please enter a positive integer."
    exit 1
fi
a=1
b=1
echo -n "$a $b"
count=2  
while [ $count -lt $n ]; do
    c=$((a + b))
    echo -n " $c"
    a=$b
    b=$c
    count=$((count + 1))
done
echo
